<?php
class Bmipasien_model extends CI_Model{
    // siaplan property
    public $id, $tanggal, $pasien, $bmi;
}
?>