<div>
<h3>Daftar Pasien</h3>
<ul>
<?php foreach ($list_pasien as $pasien): ?>
    <li><?= "Id Pasien = " .$pasien->id ?></li>
    </br>
    <li><?= "Kode Pasien = " .$pasien->kode ?></li>
    </br>
    <li><?= "Nama Pasien = " .$pasien->nama ?></li>
    </br>
    <li><?= "Jenis Kelamin Pasien = " .$pasien->gender ?></li>
    </br>
    <?php endforeach; ?>
</ul>
</div>