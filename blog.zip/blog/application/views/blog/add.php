<div id="page-content-wrapper">
	<h2>Tambah Pasien</h2>
  <form action="">
    Nama Blog: <input type="text">
  </form>
</div>